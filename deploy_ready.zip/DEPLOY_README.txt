DEPLOY_README

1. QUÉ CARPETA SUBIR:
Sube todo el contenido de esta carpeta (deploy_ready/) a la raíz de tu hosting (public_html o similar).

2. ARCHIVO HOME:
El archivo principal es index.html.

3. NOTA DE RUTAS:
Todas las rutas de assets, imágenes, CSS y JS han sido configuradas como RELATIVAS (base: './'). 
Esto garantiza que el sitio funcione correctamente tanto en la raíz como en subcarpetas del hosting.

4. BLOG:
La Biblioteca Nuclear está en blog.html. 
Se incluye un archivo CanonGillBlog.html para compatibilidad con enlaces antiguos.
